//>>built
define("dijit/nls/tr/common",({buttonOk:"Tamam",buttonCancel:"İptal",buttonSave:"Kaydet",itemClose:"Kapat"}));
